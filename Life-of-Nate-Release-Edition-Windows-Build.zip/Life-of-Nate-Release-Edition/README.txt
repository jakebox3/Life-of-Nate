LIFE OF NATE RELEASE EDITION — WINDOWS DESKTOP BUILD

This folder wraps the existing HTML game in a desktop window and can build a Windows installer and portable EXE.

HOW TO BUILD THE EXE (on Windows):
1. Install Node.js LTS from https://nodejs.org/ if it is not already installed.
2. Extract this entire folder somewhere writable.
3. Double-click build-windows.bat.
4. Wait for npm to download the desktop build tools. An internet connection is required.
5. The generated files will be in the dist folder:
   - Life-of-Nate-Release-Edition-Setup.exe (installer)
   - Life-of-Nate-Release-Edition-Portable.exe (portable version, if build succeeds)

To run in a desktop window without packaging, open a terminal in this folder and run:
   npm install
   npm start

IMPORTANT:
The game currently loads Three.js and some fonts from online CDNs, so an internet connection is still needed for those resources. This package contains the HTML game and desktop wrapper; it does not contain a prebuilt Windows EXE.
