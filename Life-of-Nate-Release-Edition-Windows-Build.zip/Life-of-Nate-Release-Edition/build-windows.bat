@echo off
setlocal
cd /d "%~dp0"
echo Building Life of Nate Release Edition for Windows...
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is required. Install the LTS version from https://nodejs.org/ then run this again.
  pause
  exit /b 1
)
call npm install
if errorlevel 1 goto failed
call npm run dist:win
if errorlevel 1 goto failed
echo.
echo Finished. Check the dist folder for the installer and portable EXE.
pause
exit /b 0
:failed
echo Build failed. Check the error above and make sure you have an internet connection.
pause
exit /b 1
